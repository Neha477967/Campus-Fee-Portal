
  # Student Fees Payment System

  This is a code bundle for Student Fees Payment System. The original project is available at https://www.figma.com/design/Yual73P1gQa47xuGYDOLH0/Student-Fees-Payment-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  