import { useState } from 'react';
import { LogOut, User, Building2, Calendar, DollarSign, CreditCard, Mail, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { PaymentDialog } from './PaymentDialog';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DashboardProps {
  student: {
    name: string;
    email: string;
    class: string;
    department: string;
    year: string;
    feesBalance: number;
    totalFees: number;
    paidFees: number;
    semester: string;
  };
  onLogout: () => void;
  onPayment: (amount: number) => void;
}

export function Dashboard({ student, onLogout, onPayment }: DashboardProps) {
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handlePaymentComplete = (amount: number) => {
    onPayment(amount);
    setShowPaymentDialog(false);
    setShowSuccessMessage(true);
    
    // Hide success message after 5 seconds
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 5000);
  };

  const paymentPercentage = ((student.paidFees / student.totalFees) * 100).toFixed(1);

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-blue-900">Campus Fee Portal</h3>
                <p className="text-sm text-gray-500">{student.semester}</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={onLogout}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Success Message */}
      {showSuccessMessage && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3 animate-in slide-in-from-top">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-green-800">
                Payment successful! A confirmation email has been sent to <strong>{student.email}</strong>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-blue-900 mb-2">Welcome back, {student.name.split(' ')[0]}!</h1>
          <p className="text-gray-600">Here's your fee information and account overview</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Student Details */}
          <div className="lg:col-span-1 space-y-6">
            {/* Profile Card */}
            <Card className="border-2 border-blue-100">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <User className="w-5 h-5" />
                  Student Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4 pb-4 border-b">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white">
                    <span className="text-2xl">{student.name.charAt(0)}</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-900">{student.name}</p>
                    <p className="text-sm text-gray-500">{student.email}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Building2 className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-500">Department</p>
                      <p className="text-gray-900">{student.department}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-500">Class & Year</p>
                      <p className="text-gray-900">{student.class}</p>
                      <Badge className="mt-1 bg-blue-100 text-blue-800 hover:bg-blue-200">
                        {student.year}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Hero Image Card */}
            <Card className="overflow-hidden hidden lg:block">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1709054172839-17880c040f22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBzdHVkeXxlbnwxfHx8fDE3NjIxNzY2NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Education"
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-4">
                <p className="text-sm text-gray-600">
                  Invest in your future with seamless fee management
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Fee Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Fee Balance Overview */}
            <Card className="border-2 border-blue-100 bg-gradient-to-br from-blue-50 to-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <DollarSign className="w-5 h-5" />
                  Fee Balance Overview
                </CardTitle>
                <CardDescription>Current semester fee status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-lg p-6 border-2 border-gray-100">
                    <p className="text-sm text-gray-500 mb-1">Total Fees</p>
                    <p className="text-gray-900">${student.totalFees.toLocaleString()}</p>
                  </div>
                  <div className="bg-white rounded-lg p-6 border-2 border-green-100">
                    <p className="text-sm text-gray-500 mb-1">Paid</p>
                    <p className="text-green-600">${student.paidFees.toLocaleString()}</p>
                  </div>
                  <div className="bg-white rounded-lg p-6 border-2 border-orange-100">
                    <p className="text-sm text-gray-500 mb-1">Outstanding Balance</p>
                    <p className="text-orange-600">${student.feesBalance.toLocaleString()}</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Payment Progress</p>
                    <p className="text-sm text-blue-600">{paymentPercentage}%</p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${paymentPercentage}%` }}
                    />
                  </div>
                </div>

                {student.feesBalance === 0 && (
                  <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <p className="text-green-800">All fees paid! You're all set for this semester.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <CreditCard className="w-5 h-5" />
                  Make a Payment
                </CardTitle>
                <CardDescription>
                  {student.feesBalance > 0 
                    ? 'Pay your outstanding fees securely' 
                    : 'No outstanding balance at this time'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {student.feesBalance > 0 ? (
                  <div className="space-y-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-sm text-blue-800 mb-3">
                        <strong>Payment Options Available:</strong>
                      </p>
                      <ul className="text-sm text-blue-700 space-y-1 ml-4">
                        <li>• Credit/Debit Card</li>
                        <li>• Bank Transfer</li>
                        <li>• Digital Wallets</li>
                      </ul>
                    </div>
                    <Button 
                      onClick={() => setShowPaymentDialog(true)}
                      className="w-full h-12 bg-blue-600 hover:bg-blue-700"
                      size="lg"
                    >
                      <CreditCard className="w-5 h-5 mr-2" />
                      Proceed to Payment
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <p className="text-gray-600">You have no outstanding fees</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Email Notification Info */}
            <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-purple-900">
                  <Mail className="w-5 h-5" />
                  Email Notifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  Payment confirmations and receipts will be sent to <strong>{student.email}</strong>
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  Make sure to check your inbox after completing a payment.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Payment Dialog */}
      <PaymentDialog
        open={showPaymentDialog}
        onClose={() => setShowPaymentDialog(false)}
        onPaymentComplete={handlePaymentComplete}
        maxAmount={student.feesBalance}
        studentEmail={student.email}
      />
    </div>
  );
}
